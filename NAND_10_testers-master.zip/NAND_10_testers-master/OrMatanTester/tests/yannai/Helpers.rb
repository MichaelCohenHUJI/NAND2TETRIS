module Helpers
  # Raise a motherly exception
  def your_momma(msg="behave yourself")
    raise "Your momma says: #{msg}"
  end
end

# EOF vim:sw=2 ts=2 et fileformat=unix:
